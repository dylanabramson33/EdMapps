**Ready Data Management**
Django==2.0.6
gunicorn==19.9.0
django-heroku==0.3.1
dj-database-url==0.5.0
Whitenoise==3.3.1
